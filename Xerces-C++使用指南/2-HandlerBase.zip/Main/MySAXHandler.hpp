#ifndef __MySAXHandler_h__
#define __MySAXHandler_h__


#include <xercesc/sax/HandlerBase.hpp>

using namespace xercesc;

class MySAXHandler : public HandlerBase {
public:
	MySAXHandler();
	virtual void startElement(const XMLCh* const name, AttributeList& attributes);
	virtual void endElement(const XMLCh* const name);

    void fatalError(const SAXParseException&);
};




#endif


