#include "MySAXHandler.hpp"
#include <iostream>

using namespace xercesc;
using namespace std;

MySAXHandler::MySAXHandler() {

}

void MySAXHandler::startElement(const XMLCh* const name,
                           AttributeList& attributes)
{
    char* message = XMLString::transcode(name);
    cout << "start element: "<< message << endl;
    XMLString::release(&message);
}

void MySAXHandler::endElement(const XMLCh* const name) 
{
	char* message = XMLString::transcode(name);
	cout << "end element: " << message << endl;
	XMLString::release(&message);
}

void MySAXHandler::fatalError(const SAXParseException& exception)
{
    char* message = XMLString::transcode(exception.getMessage());
    cout << "Fatal Error: " << message
         << " at line: " << exception.getLineNumber()
         << endl;
    XMLString::release(&message);
}