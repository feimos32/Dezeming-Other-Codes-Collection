#include <iostream>
#include <xercesc/util/PlatformUtils.hpp>
#include <xercesc/sax/HandlerBase.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/parsers/SAXParser.hpp>

#include "MySAXHandler.hpp"

using std::cout;
using std::endl;
using namespace xercesc;

int main(int argc, char* argv[]){
	
	try {
		XMLPlatformUtils::Initialize();
	}
	catch (const XMLException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		cout << "Error during initialization! :\n"
			<< message << "\n";
		XMLString::release(&message);
		return 1;
	}


	char* xmlFile = "Resources/cbox.xml";
	SAXParser* parser = new SAXParser();
	parser->setDoNamespaces(true); 

	DocumentHandler* docHandler = new MySAXHandler();
	ErrorHandler* errHandler = (ErrorHandler*)docHandler;
	parser->setDocumentHandler(docHandler);
	parser->setErrorHandler(errHandler);

	try {
		parser->parse(xmlFile);
	}
	catch (const XMLException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		cout << "Exception message is: \n"
			<< message << "\n";
		XMLString::release(&message);
		return -1;
	}
	catch (const SAXParseException& toCatch) {
		char* message = XMLString::transcode(toCatch.getMessage());
		cout << "Exception message is: \n"
			<< message << "\n";
		XMLString::release(&message);
		return -1;
	}
	catch (...) {
		cout << "Unexpected Exception \n";
		return -1;
	}

	delete parser;
	delete docHandler;


	XMLPlatformUtils::Terminate();

	// Other terminations and cleanup.
	return 0;
}





